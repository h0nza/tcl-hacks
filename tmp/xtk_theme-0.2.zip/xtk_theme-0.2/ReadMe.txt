#******************************************************************************
#				XTK Theme
#******************************************************************************

package require xtk::theme

DESCRIPTION

	This package creates with 'gtk2' and 'tk' two new ttk::themes, which
	takes respect of the system colors. With the internal 'ttk.tcl' script,
	the different widget sets, tk and ttk, will get uniform colors.

	'gtk2' tries to read the current gtk2 theme at startup and falls back
	to the builtin config file.

	'tk' read the current system/X11 colors at startup.

	The 'tk' theme is the default, except it founds xfce or gnome as the
	current running desktop from the env variable DESKTOP_SESSION. Then
	'gtk2' will be the default.

COMMANDS

	::xtk::theme::ttk::init <Theme>
		This procedure provide the uniform look for the 'tk' and 'ttk'
		widgets.
		You should use this procedure to change the ttk::themes,
		instead of 'ttk::style theme use <Theme>'.

VARIABLES

	::xtk::theme::gtk2::Color
	::xtk::theme::tk::Color
		These color arrays are structered like the gtk colors for three
		widget types with six back/fore color pairs, one for each state
		and one for light/dark.

		The widget types are:
			- Standard for frame, label ...
			- Form for button ...
			- Input for entry, text ...

		The widget states are:
			- Normal
			- Select
			- Active
			- Highlight
			- Disabled

		Color(Standard,Normal,Back)
		Color(Standard,Normal,Fore)
		.
		.
		.
		Color(Standard,Light)
		Color(Standard,Dark)
