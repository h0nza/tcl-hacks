#******************************************************************************
#				XTK WM
#******************************************************************************

USAGE

	package require xtk::wm

DESCRIPTION

	Extended wm command.

	It provides ...
		- a screen layout for multiple displays with xinerama and a
			procedure for a user defined screen layout, which is
			saved in the array 'xtk::wm::Screen'.
		- calculation of a given anchor position (n,w,e,s,c) on the
			screen.
		- a procedure to move windows without decorations.

	On X11 it tries to use xdpyinfo for screen layout and xwininfo for the
	window decoration, which fallsback to a tcl-only solution.

	The anchor position takes no care of toolbars.

COMMANDS

	::xtk::wm::setScreens <ArrayName>
		With this proc you can import a handy written global array into
		the namespace variable. The array must have indexed keys and
		contain a list of values [list X Y W H]. Example:
			ArrayName(0)	[list 0 0 2240 768]	# Whole screen
			ArrayName(1)	[list 0 0 960 768]	# First screen
			ArrayName(2)	[list 960 0 1280 768]	# Second screen
		This will be read into the namespace array '::xtk::wm::Screen'.

	::xtk::wm::splash
		Creates a small splash screen with a tcl image. This is used
		to get the global decoration settings, but is not needed
		anymore. It's a toplevel named '.splash' and returns a list
		of borderwidth, which is saved in the array 'Border' with
		keys Left ,Top ,Right ,Bottom.
		If you use it, you can close it with 'destroy .splash'

	::xtk::wm::anchor <Win> ?args?
		Sets <Win> to the position of given anchor. <args> are:
			-a|-anchor <Anchor>
				Anchor is one ore more of nswec.
				An anchor like 'we' would maximize the window
				horizontal.
			-g|-geometry <Geometry>
				Classic geometry string (WxH+X+Y), but only W
				and H are used.
			-s|-screen <Nr>
				Defines the screen, where the anchor position
				will be calculated. If given, but no anchor,
				anchor defaults to c.
				<Nr> can also be 'c' to define the current
				screen.

		Hint:
		Depending of the environment, it's recommended to first
		deiconify before using the 'anchor' command.

	::xtk::wm::move <Win> <X> <Y>
		Uses <Win> to move the toplevel window.
		Example to use the menubar to move the toplevel:
			bind <Menubar>	<B1-Motion>	{
				::xtk::wm::move %W %X %Y
			}

HELPERS

	Helpers are used automatically, and should not used by the
	programmers!?

	::xtk::wm::getScreens
		Tries to read the xinerama settings to get the screen layout.

	::xtk::wm::getCurScreens [list x y]
		Get the current screen, where the pointer is.

	::xtk::wm::decor <Win>
		Calculates the window decoration of <Win> and is used
		automatically by the 'anchor' proc. Returns a list with
		Left-, Top-, Right-, Bottom-Border.

VARIABLES

	::xtk::wm::Screen
		Array with the screen layout. See 'setScreens'.
