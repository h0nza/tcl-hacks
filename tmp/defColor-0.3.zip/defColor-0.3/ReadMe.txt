#******************************************************************************
#				::defColor
#******************************************************************************

package require defColor ?0.3?

DESCRIPTION
	Procedures for color definitions, like ...
		o Tint and mix colors
		o Translate color formats and names, default output is #HHeexx
		o Search nearest name of given color
		o Takes care of additional 'SystemColors' on windows

COMMANDS

	::defColor::reverse <Color1> <Color2>
		Reverse Colors
		Output: [list <Color2> <Color1>]

	::defColor::mix <BaseColor> ?<MixColor>? ?<MixValue>?
		Mix <BaseColor> with <MixColor> with the strength of
		<MixValue> (0-100).
		Defaults: <MixColor> defaults to black or white depending of
		Brightness of <BaseColor>. <MixValue> defaults to 50.
		Output: <HexColor>

	::defColor::tint <Color> ?<TintValue>?
		Create lighter and darker color from given color with the
		strength of <TintValue> (0-100)
		Defaults: <TintValue> defaults to 50.
		Output: [list <LighterColor> <DarkerColor>]

	::defColor::crFore <BackColor>
		Set black or white <ForeColor> depending of <BackColor>
		Output: <ForeColor>

	::defColor::luminance <Color>
		Calculate brightness level.
		Output: <Percent>

	::defColor::nearestName <Color>
		Search nearest <ColorName> of <Color>
		Output: [list <ColorName> <Differenz>]

	Internal Helpers:
		::defColor::conv2List <Color>
		::defColor::conv2Hex <Color>
		::defColor::list2Hex [list R G B]
		::defColor::conv2Perc <Color>

	Old, for compatibility:
		::defColor::isBright <Color>
		::defColor::brightLevel <Color>
		::defColor::listNames
		::defColor::validate <Color>

VARIABLES

	::defColor::ColorNames
		List of all known color names. Each color definition is a
		sublist like [list <Red> <Green> <Blue> <Name> <RGB-Sum>]
