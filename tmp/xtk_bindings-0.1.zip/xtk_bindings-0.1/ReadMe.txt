#******************************************************************************
#				XTk Bindings
#******************************************************************************

package require xtk::bindings ?0.1?

DESCRIPTION

	Helpful bindings for ttk widgets.
	DONE: Search bindings for ttk::combobox.

COMMANDS

	::xtk::bindings::combobox <Win>
		Activate bindings for <Win>.

		Search bindings:
		Shows only matched values starting with content of entry field
		in the dropdown list.
